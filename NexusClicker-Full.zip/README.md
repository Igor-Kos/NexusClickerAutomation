# Nexus Clicker

[English](#english) | [Русский](#русский)

## English

Nexus Clicker clicks the download buttons for you while Vortex downloads a Nexus Mods collection on a free account.

Without Nexus Premium, every mod in a collection needs two clicks: "Download manually" in Vortex, then "Slow download" on the mod page that opens in your browser. A big collection means hundreds of clicks. Nexus Clicker does both, so you can start the collection and walk away.

It works with collections for any game on Nexus Mods. It only clicks those two buttons: it does not install mods, change settings or fix errors.

### What you need

- Windows 10 or 11
- Vortex, with the Nexus Mods collection you want to install
- Your default browser: Firefox, Chrome, Edge or Yandex Browser (Vortex opens mod pages there)

### How to use it

1. Download [NexusClicker.zip](../../releases/latest/download/NexusClicker.zip) from the latest release. `NexusClicker-Full.zip` is the same app plus the source code, you don't need it.
2. Right-click the zip, choose Extract All, and extract it into a folder of its own, for example `C:\NexusClicker`. Avoid `Program Files`: the app saves files next to itself.
3. Open that folder and run `NexusClicker.exe`. If Windows says "Windows protected your PC", click More info, then Run anyway.
4. Choose your language and your default browser.
5. Add the extension to that browser. The app shows the steps and opens the right page for you:
   - Chrome, Edge, Yandex Browser: turn on Developer mode, click Load unpacked, select the `browser_extension` folder next to the app.
   - Firefox: click Load Temporary Add-on and select `manifest.json` in the `firefox_extension` folder. Firefox forgets it on restart, so repeat this step after each restart.

   Tick the box to confirm and continue.
6. Open Vortex. If the app asks you to, click Restart Vortex and confirm.
7. Click Start, then start downloading your collection in Vortex. Leave both open until it's done.

Next time, just open the app and click through. It remembers your choices.

### Optional: stop Vortex popping up

Vortex jumps to the front for every mod. To stop that, install [Windhawk](https://windhawk.net/) with the [Prevent Focus Stealing](https://windhawk.net/mods/prevent-focus-stealing) mod and add Vortex to it. After that, all you'll notice are browser tabs opening and closing.

### Good to know

- The counter in the app counts clicks, not finished downloads. Keep an eye on Vortex for anything else it asks you.
- Settings and logs live in `%LOCALAPPDATA%\NexusClickerDesktop`. To remove the app completely, delete that folder and the app's folder.
- Use at your own risk: Nexus Mods' terms don't allow automated tools on their site, and accounts that break them can be suspended.

## Русский

Nexus Clicker сам нажимает кнопки загрузки, пока Vortex скачивает коллекцию с Nexus Mods на бесплатном аккаунте.

Без Nexus Premium каждый мод в коллекции требует двух нажатий: «Download manually» в Vortex и «Slow download» на странице мода, которая открывается в браузере. В большой коллекции это сотни нажатий. Nexus Clicker делает их за вас: запустили загрузку коллекции и можно отойти.

Подходит для коллекций к любой игре на Nexus Mods. Программа нажимает только эти две кнопки: она не устанавливает моды, не меняет настройки и не исправляет ошибки.

### Что понадобится

- Windows 10 или 11
- Vortex и коллекция с Nexus Mods, которую вы хотите установить
- Браузер по умолчанию: Firefox, Chrome, Edge или Яндекс Браузер (Vortex открывает страницы модов именно в нём)

### Как пользоваться

1. Скачайте [NexusClicker.zip](../../releases/latest/download/NexusClicker.zip) из последнего релиза. В `NexusClicker-Full.zip` та же программа плюс исходный код, обычному пользователю он не нужен.
2. Нажмите на архив правой кнопкой мыши, выберите «Извлечь все» и распакуйте его в отдельную папку, например `C:\NexusClicker`. Не используйте `Program Files`: программа сохраняет файлы рядом с собой.
3. Откройте эту папку и запустите `NexusClicker.exe`. Если появится окно «Система Windows защитила ваш компьютер», нажмите «Подробнее», затем «Выполнить в любом случае».
4. Выберите язык и свой браузер по умолчанию.
5. Добавьте расширение в этот браузер. Программа покажет шаги и сама откроет нужную страницу:
   - Chrome, Edge, Яндекс Браузер: включите «Режим разработчика», нажмите «Загрузить распакованное расширение» и выберите папку `browser_extension` рядом с программой.
   - Firefox: нажмите «Загрузить временное дополнение» и выберите файл `manifest.json` в папке `firefox_extension`. После перезапуска Firefox расширение пропадает, поэтому этот шаг нужно повторять.

   Поставьте галочку и нажмите «Продолжить».
6. Откройте Vortex. Если программа попросит, нажмите «Перезапустить Vortex» и подтвердите.
7. Нажмите «Запустить» и начните загрузку коллекции в Vortex. Не закрывайте обе программы до конца загрузки.

В следующий раз просто откройте программу и пройдите шаги: она запоминает ваш выбор.

### По желанию: чтобы Vortex не всплывал

Vortex выскакивает поверх всех окон на каждом моде. Чтобы этого не было, установите [Windhawk](https://windhawk.net/) с модом [Prevent Focus Stealing](https://windhawk.net/mods/prevent-focus-stealing) и добавьте в него Vortex. После этого вы будете замечать только вкладки, которые открываются и закрываются в браузере.

### Полезно знать

- Счётчик в программе считает нажатия, а не завершённые загрузки. Если Vortex о чём-то спросит, ответьте сами.
- Настройки и журнал хранятся в `%LOCALAPPDATA%\NexusClickerDesktop`. Чтобы удалить программу полностью, удалите эту папку и папку с программой.
- Вы используете программу на свой страх и риск: правила Nexus Mods запрещают автоматические инструменты на сайте, за нарушение аккаунт могут заблокировать.

## For developers

The source is in this repository: `app.py` (desktop app and setup wizard), `runner.py` (watches Vortex), `browser_extension/` (Chrome, Edge, Yandex), `firefox_extension/` and `tests/`.

On Windows with Python 3.10 or newer, run `install.bat` once. Then `launch.bat` runs the app from source and `build_exe.bat` builds `dist\NexusClicker.exe`. Run the tests with:

```
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Each release has three files:

- `NexusClicker.zip`: `NexusClicker.exe` plus the `browser_extension` and `firefox_extension` folders. This is the one users download.
- `NexusClicker-Full.zip`: everything in this repository plus `NexusClicker.exe`.
- `README.txt`: the user instructions from this page as plain text.

## License

[MIT](LICENSE)
