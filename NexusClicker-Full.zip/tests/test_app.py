import os
import fnmatch
import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlparse
from unittest.mock import Mock, patch

from app import (
    BrowserOption,
    DesktopApp,
    TEXT,
    detect_browsers,
    extension_directory,
    extension_folder_name,
    extension_fingerprint,
    install_extension_files,
    restart_vortex_with_accessibility,
    vortex_accessibility_ready,
)


class LocalizationTests(unittest.TestCase):
    def test_english_and_russian_have_identical_keys(self):
        self.assertEqual(set(TEXT["en"]), set(TEXT["ru"]))

    def test_restart_timeout_is_localized(self):
        self.assertTrue(TEXT["en"]["restart_timeout"])
        self.assertTrue(TEXT["ru"]["restart_timeout"])

    def test_extension_fingerprint_ignores_managed_version_marker(self):
        with tempfile.TemporaryDirectory() as directory:
            extension = Path(directory)
            (extension / "manifest.json").write_text("{}", encoding="utf-8")
            (extension / "content.js").write_text("content", encoding="utf-8")
            before = extension_fingerprint(extension)
            (extension / ".bundled-version").write_text("managed marker", encoding="utf-8")
            self.assertEqual(before, extension_fingerprint(extension))

    def test_browser_extensions_match_mod_pages_for_any_nexus_game(self):
        project_root = Path(__file__).resolve().parents[1]
        examples = (
            "https://www.nexusmods.com/skyrimspecialedition/mods/456",
            "https://www.nexusmods.com/fallout4/mods/123",
            "https://www.nexusmods.com/a-game-with-dashes/mods/789?tab=files",
        )
        for folder in ("browser_extension", "firefox_extension"):
            manifest = json.loads(
                (project_root / folder / "manifest.json").read_text(encoding="utf-8")
            )
            if folder == "browser_extension":
                self.assertEqual(
                    manifest["host_permissions"],
                    ["https://www.nexusmods.com/*/mods/*"],
                )
            else:
                self.assertIn(
                    "https://www.nexusmods.com/*/mods/*",
                    manifest["permissions"],
                )
            for pattern in manifest["content_scripts"][0]["matches"]:
                scheme, remainder = pattern.split("://", 1)
                host, path_pattern = remainder.split("/", 1)
                self.assertEqual(scheme, "https")
                self.assertEqual(host, "www.nexusmods.com")
                self.assertEqual(path_pattern, "*/mods/*")
                for url in examples:
                    parsed = urlparse(url)
                    self.assertEqual(parsed.scheme, scheme)
                    self.assertEqual(parsed.netloc, host)
                    self.assertTrue(fnmatch.fnmatchcase(parsed.path, f"/{path_pattern}"))
                for url in (
                    "https://www.nexusmods.com/games",
                    "https://www.nexusmods.com/games/collections/123",
                    "https://example.com/fallout4/mods/123",
                    "http://www.nexusmods.com/fallout4/mods/123",
                ):
                    parsed = urlparse(url)
                    self.assertFalse(
                        parsed.scheme == scheme
                        and parsed.netloc == host
                        and fnmatch.fnmatchcase(parsed.path, f"/{path_pattern}")
                    )

    def test_nexus_tab_filters_accept_variable_game_slugs(self):
        project_root = Path(__file__).resolve().parents[1]
        self.assertIn(
            r"^\/[^/]+\/mods\/\d+\/?$",
            (project_root / "browser_extension" / "background.js").read_text(
                encoding="utf-8"
            ),
        )
        self.assertIn(
            r"\/[^/]+\/mods\/",
            (project_root / "firefox_extension" / "background.js").read_text(
                encoding="utf-8"
            ),
        )

    def test_browser_detection_returns_a_list(self):
        self.assertIsInstance(detect_browsers(), list)

    def test_browser_detection_finds_firefox_install(self):
        with (
            patch.dict(
                os.environ,
                {
                    "LOCALAPPDATA": r"C:\Test\Local",
                    "PROGRAMFILES": r"C:\Test\Program Files",
                    "PROGRAMFILES(X86)": r"C:\Test\Program Files (x86)",
                },
            ),
            patch("app._registry_executable", return_value=None),
            patch.object(
                Path,
                "is_file",
                autospec=True,
                side_effect=lambda path: path.name == "firefox.exe",
            ),
        ):
            browsers = detect_browsers()
        firefox = next(browser for browser in browsers if browser.key == "firefox")
        self.assertEqual(firefox.name, "Mozilla Firefox")
        self.assertEqual(firefox.executable.name, "firefox.exe")

    def test_extension_directory_is_next_to_bundled_executable(self):
        with tempfile.TemporaryDirectory() as directory:
            executable = Path(directory) / "NexusClicker.exe"
            with (
                patch("app.sys.frozen", True, create=True),
                patch("app.sys.executable", str(executable)),
            ):
                self.assertEqual(
                    extension_directory("firefox"),
                    Path(directory) / "firefox_extension",
                )
                self.assertEqual(
                    extension_directory("chrome"),
                    Path(directory) / "browser_extension",
                )

    def test_firefox_extension_extracts_beside_executable(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            bundled = root / "bundled_firefox"
            bundled.mkdir()
            (bundled / "manifest.json").write_text("{}", encoding="utf-8")
            (bundled / "background.js").write_text("background", encoding="utf-8")
            exe_dir = root / "exe"
            exe_dir.mkdir()
            with (
                patch("app.resource_path", return_value=bundled),
                patch("app.extension_directory", return_value=exe_dir / "firefox_extension"),
            ):
                destination, changed = install_extension_files("firefox")
                self.assertTrue(changed)
                self.assertEqual(destination.parent, exe_dir)
                self.assertTrue((destination / "manifest.json").is_file())
                _, changed_again = install_extension_files("firefox")
            self.assertFalse(changed_again)

    def test_vortex_patch_starts_with_accessibility_flag_when_vortex_is_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            executable = Path(directory) / "Vortex.exe"
            executable.touch()
            with (
                patch("app.vortex_running", return_value=False),
                patch("app.find_vortex", return_value=executable),
                patch("app.subprocess.Popen") as popen,
                patch("app.vortex_accessibility_ready", side_effect=[False, True]),
                patch("app.time.sleep"),
            ):
                restart_vortex_with_accessibility()
        popen.assert_called_once_with(
            [str(executable), "--force-renderer-accessibility"],
            cwd=str(executable.parent),
        )

    def test_vortex_patch_refuses_to_close_ambiguous_running_windows(self):
        with (
            patch("app.vortex_running", return_value=True),
            patch("app.visible_vortex_windows", return_value=[]),
            patch("app.subprocess.Popen") as popen,
        ):
            with self.assertRaisesRegex(RuntimeError, "Close Vortex yourself"):
                restart_vortex_with_accessibility()
        popen.assert_not_called()

    def test_vortex_patch_requires_user_confirmation(self):
        app = SimpleNamespace(
            vortex_patch_pending=False,
            t=lambda key: key,
            vortex_state=SimpleNamespace(set=Mock()),
            vortex_check_button=Mock(),
            vortex_patch_button=Mock(),
            start_button=Mock(),
        )
        with (
            patch("app.messagebox.askyesno", return_value=False) as ask,
            patch("app.threading.Thread") as thread,
        ):
            DesktopApp._apply_vortex_patch(app)
        ask.assert_called_once()
        thread.assert_not_called()

    def test_welcome_continue_is_not_gated_on_vortex_state(self):
        continue_button = Mock()
        app = SimpleNamespace(
            page="",
            _clear=Mock(),
            _heading=Mock(),
            _footer=Mock(return_value=continue_button),
            t=lambda key: key,
            _continue_after_welcome=Mock(),
        )
        DesktopApp.show_welcome(app)
        app._footer.assert_called_once_with(True, app._continue_after_welcome)
        continue_button.configure.assert_not_called()

    def test_accessibility_probe_requires_a_visible_vortex_uia_window(self):
        window = Mock()
        window.is_visible.return_value = True
        window.descendants.return_value = [Mock()]
        desktop = Mock()
        desktop.windows.return_value = [window]
        with patch("pywinauto.Desktop", return_value=desktop):
            self.assertTrue(vortex_accessibility_ready())
        desktop.windows.assert_called_once_with(
            title_re=r"^Vortex(?:$|\s.*)",
            visible_only=True,
        )
        window.descendants.assert_called_once_with(control_type="Button")

    def test_accessibility_probe_rejects_empty_vortex_tree(self):
        window = Mock()
        window.is_visible.return_value = True
        window.descendants.return_value = []
        desktop = Mock()
        desktop.windows.return_value = [window]
        with patch("pywinauto.Desktop", return_value=desktop):
            self.assertFalse(vortex_accessibility_ready())

    def test_vortex_probe_uses_window_accessibility_without_tasklist(self):
        window = Mock()
        window.descendants.return_value = [Mock()]
        app = SimpleNamespace(events=Mock())
        with (
            patch("app.visible_vortex_windows", return_value=[window]),
            patch("app.vortex_running", side_effect=AssertionError("tasklist should not run")),
        ):
            DesktopApp._probe_vortex_accessibility(app)
        app.events.put.assert_called_once_with(("vortex_check", "ready"))

    def test_dark_mode_preference_is_persisted(self):
        app = SimpleNamespace(
            dark_mode=SimpleNamespace(get=lambda: True, set=Mock()),
            settings={"language": "en", "browser": "firefox"},
            _apply_theme=Mock(),
            t=lambda key: key,
        )
        with tempfile.TemporaryDirectory() as directory:
            config_path = Path(directory) / "settings.json"
            with (
                patch("app.APP_DIR", Path(directory)),
                patch("app.CONFIG_PATH", config_path),
            ):
                DesktopApp._toggle_dark_mode(app)
            settings = json.loads(config_path.read_text(encoding="utf-8"))
        self.assertTrue(settings["dark_mode"])
        self.assertEqual(settings["browser"], "firefox")
        app._apply_theme.assert_called_once_with()

    def test_setup_starts_runner_without_launching_vortex(self):
        app = SimpleNamespace(
            extension_confirmed=SimpleNamespace(get=lambda: True),
            vortex_ready=True,
            _save_settings=Mock(),
            _start_runner=Mock(),
            t=lambda key: key,
            start_button=Mock(),
            vortex_state=SimpleNamespace(set=Mock()),
        )
        with patch(
            "app.vortex_running",
            side_effect=subprocess.TimeoutExpired("tasklist.exe", 5),
        ) as process_check:
            DesktopApp._start_from_setup(app)
        app._save_settings.assert_called_once_with()
        app._start_runner.assert_called_once_with()
        process_check.assert_not_called()

    def test_pause_button_resumes_a_live_runner(self):
        pause_event = Mock()
        pause_event.is_set.return_value = False
        runner = SimpleNamespace(pause_event=pause_event, resume=Mock(), pause=Mock())
        app = SimpleNamespace(
            runner=runner,
            worker=SimpleNamespace(is_alive=lambda: True),
            status=SimpleNamespace(set=Mock()),
            t=lambda key: key,
            pause_button=Mock(),
            scan_health_var=SimpleNamespace(set=Mock()),
            last_scan_health_time=0,
            scan_health_warning=True,
        )
        DesktopApp._toggle_pause(app)
        runner.resume.assert_called_once_with()
        runner.pause.assert_not_called()
        app.pause_button.configure.assert_called_once_with(text="pause")
        self.assertFalse(app.scan_health_warning)

    def test_extension_continue_button_is_disabled_until_confirmed(self):
        button = Mock()
        app = SimpleNamespace(
            extension_confirmed=SimpleNamespace(get=lambda: False),
            extension_continue_button=button,
        )
        DesktopApp._update_extension_continue_state(app)
        button.configure.assert_called_once_with(state="disabled")

    def test_extension_confirmation_records_browser_and_enables_continue(self):
        button = Mock()
        app = SimpleNamespace(
            extension_confirmed=SimpleNamespace(get=lambda: True),
            extension_confirmed_browser=None,
            extension_continue_button=button,
            _update_extension_continue_state=Mock(),
            selected_browser=lambda: BrowserOption(
                "firefox", "Firefox", Path("firefox.exe"), "about:debugging"
            ),
        )
        DesktopApp._extension_confirmation_changed(app)
        self.assertEqual(app.extension_confirmed_browser, "firefox")
        app._update_extension_continue_state.assert_called_once_with()

    def test_extension_continue_does_not_advance_without_confirmation(self):
        app = SimpleNamespace(
            extension_confirmed=SimpleNamespace(get=lambda: False),
            show_vortex_page=Mock(),
        )
        DesktopApp._continue_after_extension(app)
        app.show_vortex_page.assert_not_called()

    def test_saved_setup_detects_extension_replacement(self):
        browser = BrowserOption("chrome", "Chrome", Path("chrome.exe"), "chrome://extensions")
        app = SimpleNamespace(
            settings={"extension_confirmed": True, "browser": "chrome"},
            browser_choice=SimpleNamespace(set=Mock()),
            extension_confirmed=SimpleNamespace(set=Mock()),
            show_extension_page=Mock(),
            show_vortex_page=Mock(),
        )
        with (
            patch("app.detect_browsers", return_value=[browser]),
            patch("app.install_extension_files", return_value=(Path("extension"), True)),
            patch("app.extension_fingerprint", return_value="current"),
        ):
            DesktopApp._continue_after_welcome(app)
        app.extension_confirmed.set.assert_called_once_with(False)
        app.show_extension_page.assert_called_once_with()
        app.show_vortex_page.assert_not_called()


if __name__ == "__main__":
    unittest.main()
