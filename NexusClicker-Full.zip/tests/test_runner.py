import tempfile
import unittest
from pathlib import Path
from queue import Queue
from unittest.mock import patch

from runner import (
    DownloadRunner,
    RunnerConfig,
    normalize_file_identity,
    read_previous_item,
    read_success_count,
    reserve_previous_item,
    write_success_count,
)


class IdentityTests(unittest.TestCase):
    def test_identity_ignores_queue_position_and_spacing(self):
        self.assertEqual(
            normalize_file_identity("  Mod   Name | 4/100"),
            normalize_file_identity("mod name|9/100"),
        )

    def test_previous_item_is_one_persisted_value(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "last-item.txt"
            reserve_previous_item(path, normalize_file_identity("First Mod|1/10"))
            self.assertEqual(read_previous_item(path), "first mod")
            reserve_previous_item(path, normalize_file_identity("Second Mod|2/10"))
            self.assertEqual(read_previous_item(path), "second mod")

    def test_success_count_persists_atomically_as_a_number(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "success-count.txt"
            self.assertEqual(read_success_count(path), 0)
            write_success_count(path, 7)
            self.assertEqual(read_success_count(path), 7)

    def test_runner_counts_only_successful_button_invocations(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            events = Queue()
            config = RunnerConfig(
                vortex_title="Vortex",
                poll_interval=0.01,
                last_item_path=root / "last-item.txt",
                success_count_path=root / "success-count.txt",
            )
            runner = DownloadRunner(config, events)

            class Button:
                def invoke(self):
                    runner.stop()

            with (
                patch("runner.acquire_single_instance", return_value=None),
                patch(
                    "runner.find_download_button",
                    return_value=(Button(), "Test Mod|1/1"),
                ),
            ):
                runner.run()

            self.assertEqual(read_success_count(config.success_count_path), 1)
            self.assertIn(("download_count", "1"), list(events.queue))


if __name__ == "__main__":
    unittest.main()
