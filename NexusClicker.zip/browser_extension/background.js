"use strict";

const inFlightPages = new Set();
const closingTabs = new Set();
const claimedTabs = new Map();
const pendingPages = new Set();
const RETRY_MS = 10000;
const retryTimers = new Map();
const retryUrls = new Map();

function pageKey(url) {
  try {
    const parsed = new URL(url);
    if (parsed.origin !== "https://www.nexusmods.com" ||
        !/^\/[^/]+\/mods\/\d+\/?$/i.test(parsed.pathname)) {
      return null;
    }
    return `${parsed.origin}${parsed.pathname.replace(/\/+$/, "")}`.toLowerCase();
  } catch {
    return null;
  }
}

function scheduleRetry(tabId, url) {
  if (retryUrls.get(tabId) === url && retryTimers.has(tabId)) {
    return;
  }
  const previous = retryTimers.get(tabId);
  if (previous) {
    clearTimeout(previous);
  }
  const timer = setTimeout(async () => {
    retryTimers.delete(tabId);
    retryUrls.delete(tabId);
    if (claimedTabs.has(tabId) || closingTabs.has(tabId)) {
      return;
    }
    try {
      const current = await chrome.tabs.get(tabId);
      if (pageKey(current.url) !== pageKey(url)) {
        return;
      }
      const replacement = await chrome.tabs.create({ url, active: false });
      if (!Number.isInteger(replacement.id)) {
        throw new Error("Browser did not return an ID for the replacement tab.");
      }
      console.warn(`No click claim after ${RETRY_MS}ms; replaced tab ${tabId} with background tab ${replacement.id}.`);
      await chrome.tabs.remove(tabId);
    } catch (error) {
      console.error("Could not reopen the Nexus page:", error);
      scheduleRetry(tabId, url);
    }
  }, RETRY_MS);
  retryTimers.set(tabId, timer);
  retryUrls.set(tabId, url);
}

async function monitorExistingTabs() {
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (!Number.isInteger(tab.id) || !pageKey(tab.url)) {
      continue;
    }
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        files: ["content.js"]
      });
      scheduleRetry(tab.id, tab.url);
    } catch (error) {
      console.warn("Could not attach the monitor to an existing tab:", error);
    }
  }
}

chrome.runtime.onInstalled.addListener(() => {
  monitorExistingTabs().catch((error) => console.error("Could not scan existing tabs:", error));
});

chrome.runtime.onStartup.addListener(() => {
  monitorExistingTabs().catch((error) => console.error("Could not scan existing tabs:", error));
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const url = changeInfo.url || tab.url;
  const key = pageKey(url);
  if (!key) {
    return;
  }
  const oldKey = claimedTabs.get(tabId);
  if (oldKey && oldKey !== key) {
    claimedTabs.delete(tabId);
    inFlightPages.delete(oldKey);
  }
  scheduleRetry(tabId, url);
});

chrome.tabs.onRemoved.addListener((tabId) => {
  const timer = retryTimers.get(tabId);
  if (timer) {
    clearTimeout(timer);
    retryTimers.delete(tabId);
  }
  retryUrls.delete(tabId);
  const key = claimedTabs.get(tabId);
  if (key) {
    inFlightPages.delete(key);
    claimedTabs.delete(tabId);
  }
  closingTabs.delete(tabId);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const tabId = sender.tab?.id;
  const key = pageKey(sender.tab?.url);

  if (message?.type === "claim-click") {
    if (!Number.isInteger(tabId) || !key) {
      sendResponse({ result: "invalid" });
      return false;
    }
    if (claimedTabs.has(tabId)) {
      sendResponse({ result: "same-tab" });
      return false;
    }
    if (inFlightPages.has(key) || pendingPages.has(key)) {
      sendResponse({ result: "duplicate-page" });
      return false;
    }

    pendingPages.add(key);
    chrome.storage.session.get("lastClaimedPageKey").then((stored) => {
      if (stored.lastClaimedPageKey === key) {
        sendResponse({ result: "duplicate-page" });
        return;
      }
      inFlightPages.add(key);
      claimedTabs.set(tabId, key);
      return chrome.storage.session.set({ lastClaimedPageKey: key }).then(() => {
        const timer = retryTimers.get(tabId);
        if (timer) {
          clearTimeout(timer);
          retryTimers.delete(tabId);
        }
        retryUrls.delete(tabId);
        sendResponse({ result: "claimed" });
      });
    }).catch((error) => {
      console.error("Could not persist the page click claim:", error);
      sendResponse({ result: "claim-error" });
    }).finally(() => {
      pendingPages.delete(key);
    });
    return true;
  }

  if (message?.type === "close-duplicate") {
    if (Number.isInteger(tabId) && key && !closingTabs.has(tabId)) {
      closingTabs.add(tabId);
      setTimeout(() => chrome.tabs.remove(tabId).catch(console.error), 100);
    }
    return;
  }

  if (message?.type === "slow-download-clicked") {
    if (!Number.isInteger(tabId) || !claimedTabs.has(tabId) || closingTabs.has(tabId)) {
      return;
    }
    closingTabs.add(tabId);
    setTimeout(() => chrome.tabs.remove(tabId).catch(console.error), 500);
  }
});
