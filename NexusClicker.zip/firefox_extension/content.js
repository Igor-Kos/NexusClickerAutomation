"use strict";

(() => {
  if (window.__nexusClickerBackgroundMonitor) {
    return;
  }

  window.__nexusClickerBackgroundMonitor = true;
  let clicked = false;
  let claiming = false;
  const originalTitle = document.title;
  let lastStatus = "";
  const observedRoots = new Set();
  let shadowRootCount = 0;

  function reportStatus(status) {
    if (status !== lastStatus) {
      document.title = `${originalTitle} [Nexus Clicker: ${status}]`;
      lastStatus = status;
      browser.runtime.sendMessage({
        type: "monitor-status",
        status,
        frameHost: window.location.hostname
      }).catch((error) => {
        console.error("Could not report the Nexus monitor status:", error);
      });
    }
  }

  function isVisible(element) {
    const style = window.getComputedStyle(element);
    const bounds = element.getBoundingClientRect();
    return style.display !== "none" &&
      style.visibility !== "hidden" &&
      Number(style.opacity) !== 0 &&
      bounds.width > 0 &&
      bounds.height > 0;
  }

  function collectOpenShadowRoots(root) {
    if (!root.querySelectorAll) {
      return;
    }

    for (const element of root.querySelectorAll("*")) {
      if (element.shadowRoot && !observedRoots.has(element.shadowRoot)) {
        observeRoot(element.shadowRoot);
      }
    }
  }

  function observeRoot(root) {
    if (observedRoots.has(root)) {
      return;
    }
    observedRoots.add(root);
    if (root instanceof ShadowRoot) {
      shadowRootCount += 1;
    }
    observer.observe(root, {
      childList: true,
      subtree: true,
      attributes: true
    });
    collectOpenShadowRoots(root);
  }

  function composedParent(element) {
    if (element.parentElement) {
      return element.parentElement;
    }
    const root = element.getRootNode();
    return root instanceof ShadowRoot ? root.host : null;
  }

  function getLabel(element) {
    return [
      element.innerText,
      element.getAttribute("aria-label"),
      element.getAttribute("title"),
      element.value,
      element.textContent
    ]
      .filter(Boolean)
      .map((text) => text.replace(/\s+/g, " ").trim().toLowerCase())
      .find((text) => /^slow download(?:$|[.\s])/.test(text));
  }

  function isWaiting(element) {
    if (element.matches(":disabled") ||
      element.getAttribute("aria-disabled") === "true") {
      return true;
    }

    return /\bwait more\b/i.test(getLabel(element) || "");
  }

  function findButtons() {
    const selector =
        'button, a, [role="button"], input[type="button"], ' +
        'input[type="submit"], [onclick], [tabindex], [class*="btn" i]';
    const buttons = [];
    for (const root of observedRoots) {
      buttons.push(...root.querySelectorAll(selector));
    }
    return buttons.filter((element) =>
      isVisible(element) && getLabel(element)
    );
  }

  async function checkForButton() {
    if (clicked || claiming) {
      return;
    }

    const buttons = findButtons();
    const readyButtons = buttons.filter((element) => !isWaiting(element));
    if (readyButtons.length !== 1) {
      if (readyButtons.length > 1) {
        reportStatus(`multiple (${readyButtons.length})`);
      } else if (buttons.length) {
        reportStatus("wait more");
      } else if (!lastStatus.includes("no control;")) {
        const selector =
          "button, a, [role='button'], input[type='button'], " +
          "input[type='submit'], [onclick], [tabindex], [class*='btn' i], " +
          "[aria-label], [title]";
        const candidates = [];
        for (const root of observedRoots) {
          candidates.push(...root.querySelectorAll(selector));
        }
        const labelMatches = candidates
          .map(getLabel)
          .filter(Boolean)
          .length;
        const nexusButtonCount = Array.from(observedRoots)
          .reduce((count, root) =>
            count + root.querySelectorAll(".nxm-button").length, 0);
        const textWalker = document.createTreeWalker(document, NodeFilter.SHOW_TEXT);
        let textMatches = 0;
        while (textWalker.nextNode()) {
          if (/^slow download(?:$|[.\s])/i.test(
            textWalker.currentNode.textContent.replace(/\s+/g, " ").trim()
          )) {
            textMatches += 1;
          }
        }
        const frameHosts = Array.from(document.querySelectorAll("iframe"))
          .map((frame) => {
            try {
              return new URL(frame.src, window.location.href).hostname;
            } catch {
              return "unknown";
            }
          })
          .filter(Boolean)
          .join(" ");
        reportStatus(
          `${window.location.hostname}${window.location.pathname}: no control; ` +
          `labels=${labelMatches}; nxm=${nexusButtonCount}; ` +
          `text=${textMatches}; shadow=${shadowRootCount}; ` +
          `frames=${frameHosts || "none"}`
        );
      }
      return;
    }

    claiming = true;
    let claimed;
    try {
      claimed = await browser.runtime.sendMessage({
        type: "claim-slow-download"
      });
    } catch (error) {
      claiming = false;
      console.error("Could not claim the Slow download click:", error);
      reportStatus("claim failed");
      return;
    }

    if (claimed === "same-tab") {
      clicked = true;
      claiming = false;
      observer.disconnect();
      window.clearInterval(pollId);
      reportStatus("already claimed in this tab");
      return;
    }

    if (claimed !== "claimed") {
      clicked = true;
      claiming = false;
      observer.disconnect();
      window.clearInterval(pollId);
      reportStatus("duplicate file; closing tab");
      browser.runtime.sendMessage({ type: "close-duplicate-page" }).catch(
        (error) => {
          console.error("Could not close the duplicate Nexus tab:", error);
        }
      );
      return;
    }

    clicked = true;
    claiming = false;
    observer.disconnect();
    window.clearInterval(pollId);
    reportStatus("clicking");
    readyButtons[0].click();
    browser.runtime.sendMessage({ type: "slow-download-clicked" }).catch(
      (error) => {
        console.error("Could not request closing the processed Nexus tab:", error);
      }
    );
    console.info("Nexus Clicker invoked Slow download.");
  }

  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node instanceof Element) {
          if (node.shadowRoot) {
            observeRoot(node.shadowRoot);
          }
          collectOpenShadowRoots(node);
        }
      }
    }
    checkForButton();
  });
  observeRoot(document);
  const pollId = window.setInterval(checkForButton, 100);
  checkForButton();
})();
