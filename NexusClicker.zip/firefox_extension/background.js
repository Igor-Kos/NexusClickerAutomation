"use strict";

const MOD_URL_PATTERN = "https://www.nexusmods.com/*/mods/*";
const failedTabs = new Map();
const claimedTabs = new Set();
const closingTabs = new Set();
const monitorRetries = new Map();
const claimedPageKeys = new Set();
const claimedTabPageKeys = new Map();
let lastClaimedPageKey = "";
const MONITOR_RETRY_DELAY = 10000;

function isModUrl(url) {
  return typeof url === "string" &&
    /^https:\/\/www\.nexusmods\.com\/[^/]+\/mods\//i.test(url);
}

function getModPageKey(url) {
  if (!isModUrl(url)) {
    return null;
  }
  const parsed = new URL(url);
  return `${parsed.origin}${parsed.pathname}`.toLowerCase();
}

function getFailedModUrl(url) {
  if (typeof url !== "string" || !url.startsWith("about:neterror?")) {
    return null;
  }

  const requestedUrl = new URLSearchParams(url.slice(url.indexOf("?") + 1)).get("u");
  return isModUrl(requestedUrl) ? requestedUrl : null;
}

function retryFailedTab(tabId, state) {
  if (state.retryScheduled) {
    return;
  }

  state.retryScheduled = true;
  const delay = Math.min(30000, 1000 * (2 ** Math.min(state.retries, 5)));
  setTimeout(() => {
    browser.tabs.reload(tabId).then(() => {
      state.retries += 1;
      state.retryScheduled = false;
      console.warn(
        `Nexus page load failed; retrying background tab ${tabId} ` +
        `(attempt ${state.retries}).`
      );
    }).catch((error) => {
      state.retryScheduled = false;
      console.error("Could not retry the failed Nexus tab:", error);
    });
  }, delay);
}

function scheduleMonitorRetry(tabId, url) {
  const previous = monitorRetries.get(tabId);
  if (previous?.url === url && (previous.timer || previous.retrying)) {
    return;
  }
  if (previous?.timer) {
    clearTimeout(previous.timer);
  }

  const state = previous?.url === url
    ? previous
    : { url, retries: 0, timer: null, retrying: false };
  state.timer = setTimeout(async () => {
    state.timer = null;
    if (
      monitorRetries.get(tabId) !== state ||
      claimedTabs.has(tabId) ||
      closingTabs.has(tabId)
    ) {
      return;
    }

    state.retrying = true;
    try {
      const tab = await browser.tabs.get(tabId);
      if (!isModUrl(tab.url) || tab.url !== state.url) {
        monitorRetries.delete(tabId);
        return;
      }

      const replacement = await browser.tabs.create({
        url: state.url,
        active: false
      });
      if (!Number.isInteger(replacement.id)) {
        throw new Error("Firefox did not return an ID for the replacement tab.");
      }

      monitorRetries.delete(tabId);
      console.warn(
        `Slow download was not claimed after ${MONITOR_RETRY_DELAY}ms; ` +
        `reopened background tab ${replacement.id} (attempt ${state.retries + 1}).`
      );
      await browser.tabs.remove(tabId);
    } catch (error) {
      console.error("Could not reopen the unprocessed Nexus tab:", error);
      state.retries += 1;
      state.retrying = false;
      scheduleMonitorRetry(tabId, state.url);
    }
  }, MONITOR_RETRY_DELAY);
  monitorRetries.set(tabId, state);
}

async function injectIntoExistingModTabs(refreshExisting = false) {
  const tabs = await browser.tabs.query({});
  for (const tab of tabs) {
    if (!Number.isInteger(tab.id)) {
      continue;
    }

    if (isModUrl(tab.url)) {
      if (refreshExisting) {
        await browser.tabs.reload(tab.id);
        continue;
      }
      await browser.tabs.executeScript(tab.id, {
        file: "content.js",
        allFrames: true
      });
      scheduleMonitorRetry(tab.id, tab.url);
      continue;
    }

    const failedUrl = getFailedModUrl(tab.url);
    if (failedUrl) {
      failedTabs.set(tab.id, {
        url: failedUrl,
        retries: 0,
        retryScheduled: false
      });
      retryFailedTab(tab.id, failedTabs.get(tab.id));
    }
  }
}

browser.runtime.onInstalled.addListener(() => {
  injectIntoExistingModTabs(true).catch((error) => {
    console.error("Could not initialize existing Nexus tabs:", error);
  });
});

browser.runtime.onStartup.addListener(() => {
  injectIntoExistingModTabs().catch((error) => {
    console.error("Could not initialize existing Nexus tabs:", error);
  });
});

browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const navigatedUrl = changeInfo.url || tab.url;
  if (isModUrl(navigatedUrl)) {
    const existing = failedTabs.get(tabId);
    failedTabs.set(tabId, {
      url: navigatedUrl,
      retries: existing?.retries || 0,
      retryScheduled: false
    });
    scheduleMonitorRetry(tabId, navigatedUrl);
    if (changeInfo.status === "complete") {
      browser.tabs.executeScript(tabId, {
        file: "content.js",
        allFrames: true
      }).catch((error) => {
        console.error("Could not attach the Nexus page monitor:", error);
      });
    }
  } else if (getFailedModUrl(navigatedUrl)) {
    if (!failedTabs.has(tabId)) {
      failedTabs.set(tabId, {
        url: getFailedModUrl(navigatedUrl),
        retries: 0,
        retryScheduled: false
      });
    }
    retryFailedTab(tabId, failedTabs.get(tabId));
  }
});

browser.tabs.onRemoved.addListener((tabId) => {
  failedTabs.delete(tabId);
  claimedTabs.delete(tabId);
  closingTabs.delete(tabId);
  const pageKey = claimedTabPageKeys.get(tabId);
  if (pageKey) {
    claimedPageKeys.delete(pageKey);
    claimedTabPageKeys.delete(tabId);
  }
  const retry = monitorRetries.get(tabId);
  if (retry?.timer) {
    clearTimeout(retry.timer);
  }
  monitorRetries.delete(tabId);
});

browser.runtime.onMessage.addListener((message, sender) => {
  if (message?.type === "claim-slow-download") {
    const tabId = sender.tab?.id;
    const pageKey = getModPageKey(sender.tab?.url);
    if (!Number.isInteger(tabId) || !pageKey) {
      return Promise.resolve(false);
    }
    if (
      claimedTabs.has(tabId) ||
      claimedPageKeys.has(pageKey) ||
      lastClaimedPageKey === pageKey
    ) {
      return Promise.resolve(
        claimedTabs.has(tabId) ? "same-tab" : "duplicate-page"
      );
    }
    claimedTabs.add(tabId);
    claimedPageKeys.add(pageKey);
    claimedTabPageKeys.set(tabId, pageKey);
    lastClaimedPageKey = pageKey;
    const retry = monitorRetries.get(tabId);
    if (retry?.timer) {
      clearTimeout(retry.timer);
    }
    monitorRetries.delete(tabId);
    return Promise.resolve("claimed");
  }

  if (
    message?.type === "close-duplicate-page" &&
    Number.isInteger(sender.tab?.id) &&
    isModUrl(sender.tab.url)
  ) {
    const tabId = sender.tab.id;
    if (!closingTabs.has(tabId)) {
      closingTabs.add(tabId);
      setTimeout(() => {
        browser.tabs.remove(tabId).catch((error) => {
          console.warn("Could not close the duplicate Nexus tab:", error);
        });
      }, 100);
    }
    return;
  }

  if (
    message?.type === "monitor-status" &&
    Number.isInteger(sender.tab?.id) &&
    isModUrl(sender.tab.url)
  ) {
    const frameHost = String(message.frameHost || "unknown")
      .replace(/[^a-z0-9./-]/gi, "");
    const status = String(message.status).replace(/[^a-z0-9 ()-]/gi, "");
    browser.tabs.executeScript(sender.tab.id, {
      code: `document.title = document.title.replace(/ \\[Nexus Clicker: .*\\]$/, "") + ${JSON.stringify(` [Nexus Clicker ${frameHost}: ${status}]`)};`
    }).catch((error) => {
      console.error("Could not show the Nexus monitor status:", error);
    });
    return;
  }

  if (
    message?.type !== "slow-download-clicked" ||
    !Number.isInteger(sender.tab?.id) ||
    !isModUrl(sender.tab.url) ||
    !claimedTabs.has(sender.tab.id) ||
    closingTabs.has(sender.tab.id)
  ) {
    return;
  }

  const tabId = sender.tab.id;
  closingTabs.add(tabId);
  setTimeout(() => {
    browser.tabs.remove(tabId).catch((error) => {
      console.warn("The processed Nexus tab was already closed:", error);
    });
  }, 500);
});
